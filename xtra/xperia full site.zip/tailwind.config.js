/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./*.html", "./js/**/*.js"],
  theme: {
    extend: {
      colors: {
        dark: '#0a0a0a',
        brand: {
          purple: '#a855f7',
          light: '#a78bfa',
        },
        light: {
          DEFAULT: '#e5e5e5',
          pure: '#ffffff'
        }
      },
      fontFamily: {
        sans: ['Heebo', 'sans-serif'],
      }
    }
  },
  plugins: [],
}